+++
title = "Publications"
date = 2017-01-01T00:00:00
math = false
highlight = false

# List format.
#   0 = Simple
#   1 = Detailed
#   2 = APA
#   3 = MLA
list_format = 3

# Optional featured image (relative to `static/img/` folder).
[header]
image = ""
caption = ""
+++
